package com.detentionmemo.app;

import android.app.Activity;
import android.print.PrintAttributes;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.animation.RotateAnimation;

import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);

        // Keep the app inside the normal system-bar area. This avoids the
        // full-screen/edge-to-edge look and the black navigation strip on phones.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        WindowInsetsControllerCompat bars = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        bars.setAppearanceLightStatusBars(true);
        bars.setAppearanceLightNavigationBars(true);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new AndroidBridge(this, webView), "Android");
        webView.loadUrl("file:///android_asset/index.html");

        // 4-second opening animation: clear, visible Bholu flag-like wave, then DETENTION MEMO.
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        FrameLayout splash = new FrameLayout(this);
        splash.setBackgroundColor(Color.WHITE);
        root.addView(splash, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.detentionmemo.app.R.drawable.ic_launcher_round);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        FrameLayout.LayoutParams lpLogo = new FrameLayout.LayoutParams(dp(112), dp(112));
        lpLogo.gravity = Gravity.CENTER;
        lpLogo.bottomMargin = dp(42);
        splash.addView(logo, lpLogo);

        TextView title = new TextView(this);
        title.setText("DETENTION MEMO");
        title.setTextColor(Color.BLACK);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        title.setAlpha(0f);
        FrameLayout.LayoutParams lpTitle = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        lpTitle.gravity = Gravity.CENTER;
        lpTitle.topMargin = dp(95);
        splash.addView(title, lpTitle);

        ScaleAnimation reveal = new ScaleAnimation(0.55f, 1f, 0.55f, 1f,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        reveal.setDuration(650);
        reveal.setFillAfter(true);
        logo.startAnimation(reveal);

        // Clearly visible flag-like wave: stronger left/right motion and longer cycles.
        RotateAnimation wave = new RotateAnimation(-12f, 12f,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        wave.setDuration(700);
        wave.setRepeatMode(Animation.REVERSE);
        wave.setRepeatCount(3);
        wave.setStartOffset(700);
        wave.setFillAfter(true);
        logo.startAnimation(wave);

        AlphaAnimation fadeTitle = new AlphaAnimation(0f, 1f);
        fadeTitle.setDuration(450);
        fadeTitle.setStartOffset(900);
        fadeTitle.setFillAfter(true);
        title.startAnimation(fadeTitle);

        setContentView(root);

        new android.os.Handler(getMainLooper()).postDelayed(() -> {
            AlphaAnimation out = new AlphaAnimation(1f, 0f);
            out.setDuration(250);
            out.setFillAfter(true);
            out.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationStart(Animation animation) {}
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationEnd(Animation animation) { splash.setVisibility(View.GONE); }
            });
            splash.startAnimation(out);
        }, 3750);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public static class AndroidBridge {
        private final Activity activity;
        private final WebView webView;
        AndroidBridge(Activity activity, WebView webView) { this.activity = activity; this.webView = webView; }

        @JavascriptInterface
        public void clearNewMemo() {
            activity.runOnUiThread(() -> {
                new android.app.AlertDialog.Builder(activity)
                        .setTitle("New Memo")
                        .setMessage("Are you sure you want to start a New Memo?\n\nCurrent unsaved data will be cleared.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("OK", (dialog, which) -> {
                            webView.evaluateJavascript("try{localStorage.removeItem('detentionMemoOfflineV1');}catch(e){}; location.reload();", null);
                        })
                        .show();
            });
        }

        @JavascriptInterface
        public void showAbout() {
            activity.runOnUiThread(() -> {
                android.widget.LinearLayout box = new android.widget.LinearLayout(activity);
                box.setOrientation(android.widget.LinearLayout.VERTICAL);
                box.setGravity(Gravity.CENTER_HORIZONTAL);
                int pad = dpLocal(20);
                box.setPadding(pad, pad, pad, pad);

                ImageView img = new ImageView(activity);
                img.setImageResource(com.detentionmemo.app.R.drawable.ic_launcher_round);
                img.setAdjustViewBounds(true);
                img.setMaxWidth(dpLocal(120));
                img.setMaxHeight(dpLocal(120));
                box.addView(img, new android.widget.LinearLayout.LayoutParams(dpLocal(110), dpLocal(110)));

                TextView title = new TextView(activity);
                title.setText("Detention Memo");
                title.setTextSize(20);
                title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
                title.setGravity(Gravity.CENTER);
                box.addView(title);

                TextView details = new TextView(activity);
                details.setText("\nDetention Memo Offline\n\nCreated by: Chander Mohan Meena SPTM Guna\nVersion: 1.0");
                details.setTextSize(16);
                details.setGravity(Gravity.CENTER);
                box.addView(details);

                new android.app.AlertDialog.Builder(activity)
                        .setView(box)
                        .setPositiveButton("Close", null)
                        .show();
            });
        }

        private int dpLocal(int value) {
            return Math.round(value * activity.getResources().getDisplayMetrics().density);
        }

        @JavascriptInterface
        public void savePdf(String base64, String name) {
            try {
                File temp = writeTempPdf(base64, name);
                Uri uri = saveToDownloads(temp, name);
                activity.runOnUiThread(() -> Toast.makeText(activity, "PDF saved: " + name, Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "PDF save failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void sharePdf(String base64, String name) {
            try {
                File temp = writeTempPdf(base64, name);
                Uri uri = getShareUri(temp);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, "Arrival Memo PDF");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(Intent.createChooser(send, "Share PDF / WhatsApp"));
            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "Share failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void printPdf(String base64, String name) {
            try {
                File temp = writeTempPdf(base64, name);
                PrintManager pm = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                pm.print("Detention Memo - " + name, new PdfPrintAdapter(temp, name), new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME)
                        .build());
            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "Print failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        private File writeTempPdf(String base64, String name) throws IOException {
            byte[] data;
            data = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
            File dir = new File(activity.getCacheDir(), "pdf");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create PDF cache");
            File f = new File(dir, safeName(name));
            try (FileOutputStream out = new FileOutputStream(f)) { out.write(data); }
            return f;
        }

        private String safeName(String name) {
            String n = name == null ? "arrival-memo.pdf" : name;
            n = n.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!n.toLowerCase().endsWith(".pdf")) n += ".pdf";
            return n;
        }

        private Uri saveToDownloads(File source, String name) throws IOException {
            String safe = safeName(name);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IOException("Cannot create Downloads file");
                try (InputStream in = new FileInputStream(source); OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Cannot open Downloads file");
                    copy(in, out);
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                activity.getContentResolver().update(uri, done, null, null);
                return uri;
            }
            File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!downloads.exists() && !downloads.mkdirs()) throw new IOException("Cannot create Downloads folder");
            File dest = new File(downloads, safe);
            try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(dest)) { copy(in, out); }
            return Uri.fromFile(dest);
        }

        private Uri getShareUri(File file) throws IOException {
            if (Build.VERSION.SDK_INT >= 24) {
                return FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", file);
            }
            return Uri.fromFile(file);
        }

        private void copy(InputStream in, OutputStream out) throws IOException {
            byte[] buf = new byte[8192]; int len;
            while ((len = in.read(buf)) != -1) out.write(buf, 0, len);
            out.flush();
        }
    }

    private static class PdfPrintAdapter extends PrintDocumentAdapter {
        private final File file; private final String name;
        PdfPrintAdapter(File file, String name) { this.file = file; this.name = name; }
        @Override public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes, CancellationSignal cancellationSignal, LayoutResultCallback callback, Bundle extras) {
            if (cancellationSignal.isCanceled()) { callback.onLayoutCancelled(); return; }
            PrintDocumentInfo info = new PrintDocumentInfo.Builder(name).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build();
            callback.onLayoutFinished(info, !newAttributes.equals(oldAttributes));
        }
        @Override public void onWrite(PageRange[] pages, ParcelFileDescriptor destination, CancellationSignal cancellationSignal, WriteResultCallback callback) {
            try (InputStream in = new FileInputStream(file); OutputStream out = new ParcelFileDescriptor.AutoCloseOutputStream(destination)) {
                byte[] buf = new byte[8192]; int len;
                while ((len = in.read(buf)) != -1) {
                    if (cancellationSignal.isCanceled()) { callback.onWriteCancelled(); return; }
                    out.write(buf, 0, len);
                }
                out.flush(); callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (Exception e) { callback.onWriteFailed(e.getMessage()); }
        }
    }
}
